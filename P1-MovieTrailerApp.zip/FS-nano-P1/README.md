App Description
This is a simple server-side application that generates a website of movie trailers.

How to Run
To run the script, download the repository and execute fresh_tomatoes.py on a Python 2.X interpreter.
The page can be accessed by opening the fresh_tomatoes.html file.